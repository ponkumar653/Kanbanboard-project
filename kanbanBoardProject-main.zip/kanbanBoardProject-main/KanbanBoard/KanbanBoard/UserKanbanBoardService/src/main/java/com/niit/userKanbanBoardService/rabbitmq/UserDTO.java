//package com.niit.userKanbanBoardService.rabbitmq;
//
//import com.niit.userKanbanBoardService.domain.Board;
//import com.niit.userKanbanBoardService.domain.Team;
//import lombok.*;
//
//import java.util.List;
//
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
//@Getter
//@Setter
//public class UserDTO {
//    private String emailId;
//    private String password;
//    private String fullName;
//    private String contact;
//    private byte[] image;
//    private List<Team> teamList;
//    private List<Board> boardTasks;
//}
