export class Status {
    constructor(public value:string,public status:number){}
}
