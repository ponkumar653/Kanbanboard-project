export class Signup {
    constructor(public fullName:string, public emailId:string, public password:string, public contact:string)
    {
        
    }
}