export class User {
    
        fullName: string= "";
        emailId: string = "";
        password:string = "";
        contact: string = "";
        image: string = "";
}