export class Mail {
    constructor(receiver:string,messageBody:string,subject:string){}
}