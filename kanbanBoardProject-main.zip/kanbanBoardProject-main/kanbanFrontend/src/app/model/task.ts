export class Tasks {
    constructor(public taskId:number, 
        public toDo:string, 
        public priority:string, 
        public dateAssign:string,
        public dueDate:string,
        public taskStatus:number)
    {
        
    }
}
