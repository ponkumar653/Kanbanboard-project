export class Member {
    constructor(public memberId:String,
        public emailId:String,
        public name:String,
        public contact:String,
        )
    {
        
    }
}